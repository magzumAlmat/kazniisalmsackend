--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

-- Started on 2025-04-16 06:13:42 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 31159)
-- Name: AuthCodes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."AuthCodes" (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    link character varying(255),
    valid_till timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."AuthCodes" OWNER TO admin;

--
-- TOC entry 223 (class 1259 OID 31158)
-- Name: AuthCodes_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."AuthCodes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AuthCodes_id_seq" OWNER TO admin;

--
-- TOC entry 3505 (class 0 OID 0)
-- Dependencies: 223
-- Name: AuthCodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."AuthCodes_id_seq" OWNED BY public."AuthCodes".id;


--
-- TOC entry 243 (class 1259 OID 31311)
-- Name: Files; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Files" (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    mimetype character varying(255) NOT NULL,
    material_id integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Files" OWNER TO admin;

--
-- TOC entry 245 (class 1259 OID 31324)
-- Name: PasswordResetTokens; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PasswordResetTokens" (
    id integer NOT NULL,
    token character varying(255) NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."PasswordResetTokens" OWNER TO admin;

--
-- TOC entry 244 (class 1259 OID 31323)
-- Name: PasswordResetTokens_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."PasswordResetTokens_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PasswordResetTokens_id_seq" OWNER TO admin;

--
-- TOC entry 3506 (class 0 OID 0)
-- Dependencies: 244
-- Name: PasswordResetTokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."PasswordResetTokens_id_seq" OWNED BY public."PasswordResetTokens".id;


--
-- TOC entry 226 (class 1259 OID 31168)
-- Name: Roles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Roles" (
    id integer NOT NULL,
    name character varying(255)
);


ALTER TABLE public."Roles" OWNER TO admin;

--
-- TOC entry 225 (class 1259 OID 31167)
-- Name: Roles_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Roles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Roles_id_seq" OWNER TO admin;

--
-- TOC entry 3507 (class 0 OID 0)
-- Dependencies: 225
-- Name: Roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Roles_id_seq" OWNED BY public."Roles".id;


--
-- TOC entry 222 (class 1259 OID 27736)
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO admin;

--
-- TOC entry 228 (class 1259 OID 31177)
-- Name: Users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255),
    phone character varying(255),
    name character varying(255),
    lastname character varying(255),
    areasofactivity character varying(255),
    review character varying(255),
    "googleId" character varying(255),
    "roleId" integer
);


ALTER TABLE public."Users" OWNER TO admin;

--
-- TOC entry 227 (class 1259 OID 31176)
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO admin;

--
-- TOC entry 3508 (class 0 OID 0)
-- Dependencies: 227
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- TOC entry 230 (class 1259 OID 31197)
-- Name: courses; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.courses OWNER TO admin;

--
-- TOC entry 229 (class 1259 OID 31196)
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courses_id_seq OWNER TO admin;

--
-- TOC entry 3509 (class 0 OID 0)
-- Dependencies: 229
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- TOC entry 234 (class 1259 OID 31224)
-- Name: exercises; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.exercises (
    exercise_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    lesson_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.exercises OWNER TO admin;

--
-- TOC entry 233 (class 1259 OID 31223)
-- Name: exercises_exercise_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.exercises_exercise_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exercises_exercise_id_seq OWNER TO admin;

--
-- TOC entry 3510 (class 0 OID 0)
-- Dependencies: 233
-- Name: exercises_exercise_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.exercises_exercise_id_seq OWNED BY public.exercises.exercise_id;


--
-- TOC entry 232 (class 1259 OID 31208)
-- Name: lessons; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.lessons (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text,
    "isReviewLesson" boolean,
    course_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lessons OWNER TO admin;

--
-- TOC entry 231 (class 1259 OID 31207)
-- Name: lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.lessons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lessons_id_seq OWNER TO admin;

--
-- TOC entry 3511 (class 0 OID 0)
-- Dependencies: 231
-- Name: lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.lessons_id_seq OWNED BY public.lessons.id;


--
-- TOC entry 236 (class 1259 OID 31240)
-- Name: materials; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.materials (
    material_id integer NOT NULL,
    title character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    file_path text NOT NULL,
    lesson_id integer
);


ALTER TABLE public.materials OWNER TO admin;

--
-- TOC entry 235 (class 1259 OID 31239)
-- Name: materials_material_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.materials_material_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.materials_material_id_seq OWNER TO admin;

--
-- TOC entry 3512 (class 0 OID 0)
-- Dependencies: 235
-- Name: materials_material_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.materials_material_id_seq OWNED BY public.materials.material_id;


--
-- TOC entry 238 (class 1259 OID 31254)
-- Name: progresses; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.progresses (
    progress_id integer NOT NULL,
    user_id integer NOT NULL,
    lesson_id integer,
    status character varying(50) DEFAULT 'not_started'::character varying,
    isfinished character varying(50) DEFAULT 'no'::character varying,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.progresses OWNER TO admin;

--
-- TOC entry 237 (class 1259 OID 31253)
-- Name: progresses_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.progresses_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.progresses_progress_id_seq OWNER TO admin;

--
-- TOC entry 3513 (class 0 OID 0)
-- Dependencies: 237
-- Name: progresses_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.progresses_progress_id_seq OWNED BY public.progresses.progress_id;


--
-- TOC entry 242 (class 1259 OID 31294)
-- Name: stream_students; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.stream_students (
    id integer NOT NULL,
    "streamId" integer NOT NULL,
    "userId" integer NOT NULL,
    "joinedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.stream_students OWNER TO admin;

--
-- TOC entry 241 (class 1259 OID 31293)
-- Name: stream_students_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.stream_students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stream_students_id_seq OWNER TO admin;

--
-- TOC entry 3514 (class 0 OID 0)
-- Dependencies: 241
-- Name: stream_students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.stream_students_id_seq OWNED BY public.stream_students.id;


--
-- TOC entry 240 (class 1259 OID 31275)
-- Name: streams; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.streams (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "startDate" timestamp with time zone NOT NULL,
    "endDate" timestamp with time zone NOT NULL,
    cost numeric(10,2) NOT NULL,
    "maxStudents" integer NOT NULL,
    "courseId" integer NOT NULL,
    "teacherId" integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.streams OWNER TO admin;

--
-- TOC entry 239 (class 1259 OID 31274)
-- Name: streams_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.streams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.streams_id_seq OWNER TO admin;

--
-- TOC entry 3515 (class 0 OID 0)
-- Dependencies: 239
-- Name: streams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.streams_id_seq OWNED BY public.streams.id;


--
-- TOC entry 3262 (class 2604 OID 31162)
-- Name: AuthCodes id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."AuthCodes" ALTER COLUMN id SET DEFAULT nextval('public."AuthCodes_id_seq"'::regclass);


--
-- TOC entry 3283 (class 2604 OID 31327)
-- Name: PasswordResetTokens id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetTokens" ALTER COLUMN id SET DEFAULT nextval('public."PasswordResetTokens_id_seq"'::regclass);


--
-- TOC entry 3263 (class 2604 OID 31171)
-- Name: Roles id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Roles" ALTER COLUMN id SET DEFAULT nextval('public."Roles_id_seq"'::regclass);


--
-- TOC entry 3264 (class 2604 OID 31180)
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- TOC entry 3265 (class 2604 OID 31200)
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- TOC entry 3271 (class 2604 OID 31227)
-- Name: exercises exercise_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.exercises ALTER COLUMN exercise_id SET DEFAULT nextval('public.exercises_exercise_id_seq'::regclass);


--
-- TOC entry 3268 (class 2604 OID 31211)
-- Name: lessons id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lessons ALTER COLUMN id SET DEFAULT nextval('public.lessons_id_seq'::regclass);


--
-- TOC entry 3274 (class 2604 OID 31243)
-- Name: materials material_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.materials ALTER COLUMN material_id SET DEFAULT nextval('public.materials_material_id_seq'::regclass);


--
-- TOC entry 3275 (class 2604 OID 31257)
-- Name: progresses progress_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.progresses ALTER COLUMN progress_id SET DEFAULT nextval('public.progresses_progress_id_seq'::regclass);


--
-- TOC entry 3281 (class 2604 OID 31297)
-- Name: stream_students id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stream_students ALTER COLUMN id SET DEFAULT nextval('public.stream_students_id_seq'::regclass);


--
-- TOC entry 3280 (class 2604 OID 31278)
-- Name: streams id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams ALTER COLUMN id SET DEFAULT nextval('public.streams_id_seq'::regclass);


--
-- TOC entry 3478 (class 0 OID 31159)
-- Dependencies: 224
-- Data for Name: AuthCodes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."AuthCodes" (id, email, link, valid_till, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3497 (class 0 OID 31311)
-- Dependencies: 243
-- Data for Name: Files; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Files" (id, name, path, mimetype, material_id, "createdAt", "updatedAt") FROM stdin;
d6a0b454-7520-42f9-bb9a-242bec69ee78	test video	uploads/test video.mp4	video/mp4	\N	2025-04-15 05:15:22.454+00	2025-04-15 05:15:22.454+00
\.


--
-- TOC entry 3499 (class 0 OID 31324)
-- Dependencies: 245
-- Data for Name: PasswordResetTokens; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."PasswordResetTokens" (id, token, "expiresAt", "userId") FROM stdin;
\.


--
-- TOC entry 3480 (class 0 OID 31168)
-- Dependencies: 226
-- Data for Name: Roles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Roles" (id, name) FROM stdin;
1	admin
2	teacher
3	student
\.


--
-- TOC entry 3476 (class 0 OID 27736)
-- Dependencies: 222
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."SequelizeMeta" (name) FROM stdin;
20250203054239-create-auth-code.js
20250203054925-role.js
20250203054926-user.js
20250203072631-create-courses.js
20250203072650-create-lessons.js
20250203072651-create-exercises.js
20250203072707-create-materials.js
20250203072714-create-progresses.js
20250219054000-create-streams.js
20250219111854-create-stream-students.js
20250221062332-create-file.js
20250221074440-add-material-id-to-files.js
20250306071613-create-password-reset-token.js
\.


--
-- TOC entry 3482 (class 0 OID 31177)
-- Dependencies: 228
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Users" (id, email, password, phone, name, lastname, areasofactivity, review, "googleId", "roleId") FROM stdin;
1	admin@example.com	$2a$10$xYWA7pJ/lor16mYLAU9kX.gWrRXLXH04Z0pmgQWhQWx4n8Mtfd9Ze	1234567890	Admin	User	\N	\N	\N	1
2	teacher@example.com	$2a$10$CMHuJqJOd.hrOz6kMKCmmu50/DRtiPTsCPiWFn0aFRefE7/Vgml52	0987654321	Teacher	User	\N	\N	\N	2
3	student@example.com	$2a$10$qC0axD9.N.Pj0K4jHQmTq.drju5YQeGFvfWwsrzg3/64X4kmilOMO	5555555555	Student	User	\N	{"time":1744306072231,"blocks":[{"id":"3mbSX1J9uu","type":"paragraph","data":{"text":"Хай эпл"}}],"version":"2.31.0-rc.7"}	\N	3
4	vlesyonarosla1990@inbox.ru	$2b$10$QMSEZ4wdtcFHtEPrtd5RtOaLoOIqP/KJfNpoiMuHm.lcFEjs4A7NK	\N	\N	\N	\N	\N	\N	\N
5	obeliks83@inbox.ru	$2a$10$DAgNTpVgiJ3W8ENU5f8lMOKTZpW0oS5OHh34yG67CSiymyvgOQnBi	\N	\N	\N	\N	{"time":1744349490083,"blocks":[{"id":"Vr5Hyeykgo","type":"paragraph","data":{"text":"Мой отзыв Ла ла ла"}}],"version":"2.31.0-rc.7"}	\N	3
6	obeliks82@inbox.ru	$2a$10$grBTahvulsno36C85pqNOuGLRYe6ovDxflzDN7NHYEoqXjeYKeeH2	\N	\N	\N	\N	{"time":1744350970677,"blocks":[{"id":"ND0fOQJATO","type":"paragraph","data":{"text":"Хай я студент , вот мой отзыв ла ла ла"}}],"version":"2.31.0-rc.7"}	\N	3
\.


--
-- TOC entry 3484 (class 0 OID 31197)
-- Dependencies: 230
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.courses (id, title, description, created_at, updated_at) FROM stdin;
1	buildingSMART11		2025-04-10 13:23:27.39+00	2025-04-10 13:23:27.39+00
\.


--
-- TOC entry 3488 (class 0 OID 31224)
-- Dependencies: 234
-- Data for Name: exercises; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.exercises (exercise_id, title, description, lesson_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3486 (class 0 OID 31208)
-- Dependencies: 232
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.lessons (id, title, content, "isReviewLesson", course_id, created_at, updated_at) FROM stdin;
1	Lesson1	{"time":1744291420287,"blocks":[{"id":"mrvxcj-DK7","type":"paragraph","data":{"text":"asdasfasfdggsdgsdg"}}],"version":"2.31.0-rc.7"}	f	1	2025-04-10 13:23:40.292+00	2025-04-10 13:23:40.292+00
4	Отзыв2	{"time":1744291667319,"blocks":[{"id":"vv3fp9Ti1q","type":"paragraph","data":{"text":"Напишите пож-ста отзыв на программу обучения buildingSMART Foundation в (произвольной форме)."}}],"version":"2.31.0-rc.7"}	t	1	2025-04-10 13:27:47.334+00	2025-04-10 13:27:47.334+00
\.


--
-- TOC entry 3490 (class 0 OID 31240)
-- Dependencies: 236
-- Data for Name: materials; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.materials (material_id, title, type, file_path, lesson_id) FROM stdin;
\.


--
-- TOC entry 3492 (class 0 OID 31254)
-- Dependencies: 238
-- Data for Name: progresses; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.progresses (progress_id, user_id, lesson_id, status, isfinished, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3496 (class 0 OID 31294)
-- Dependencies: 242
-- Data for Name: stream_students; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.stream_students (id, "streamId", "userId", "joinedAt") FROM stdin;
\.


--
-- TOC entry 3494 (class 0 OID 31275)
-- Dependencies: 240
-- Data for Name: streams; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.streams (id, name, "startDate", "endDate", cost, "maxStudents", "courseId", "teacherId", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3516 (class 0 OID 0)
-- Dependencies: 223
-- Name: AuthCodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."AuthCodes_id_seq"', 1, false);


--
-- TOC entry 3517 (class 0 OID 0)
-- Dependencies: 244
-- Name: PasswordResetTokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."PasswordResetTokens_id_seq"', 1, true);


--
-- TOC entry 3518 (class 0 OID 0)
-- Dependencies: 225
-- Name: Roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Roles_id_seq"', 3, true);


--
-- TOC entry 3519 (class 0 OID 0)
-- Dependencies: 227
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Users_id_seq"', 6, true);


--
-- TOC entry 3520 (class 0 OID 0)
-- Dependencies: 229
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.courses_id_seq', 1, true);


--
-- TOC entry 3521 (class 0 OID 0)
-- Dependencies: 233
-- Name: exercises_exercise_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.exercises_exercise_id_seq', 1, false);


--
-- TOC entry 3522 (class 0 OID 0)
-- Dependencies: 231
-- Name: lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.lessons_id_seq', 4, true);


--
-- TOC entry 3523 (class 0 OID 0)
-- Dependencies: 235
-- Name: materials_material_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.materials_material_id_seq', 4, true);


--
-- TOC entry 3524 (class 0 OID 0)
-- Dependencies: 237
-- Name: progresses_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.progresses_progress_id_seq', 5, true);


--
-- TOC entry 3525 (class 0 OID 0)
-- Dependencies: 241
-- Name: stream_students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.stream_students_id_seq', 1, false);


--
-- TOC entry 3526 (class 0 OID 0)
-- Dependencies: 239
-- Name: streams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.streams_id_seq', 1, false);


--
-- TOC entry 3287 (class 2606 OID 31166)
-- Name: AuthCodes AuthCodes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."AuthCodes"
    ADD CONSTRAINT "AuthCodes_pkey" PRIMARY KEY (id);


--
-- TOC entry 3317 (class 2606 OID 31317)
-- Name: Files Files_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_pkey" PRIMARY KEY (id);


--
-- TOC entry 3319 (class 2606 OID 31329)
-- Name: PasswordResetTokens PasswordResetTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetTokens"
    ADD CONSTRAINT "PasswordResetTokens_pkey" PRIMARY KEY (id);


--
-- TOC entry 3321 (class 2606 OID 31331)
-- Name: PasswordResetTokens PasswordResetTokens_token_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetTokens"
    ADD CONSTRAINT "PasswordResetTokens_token_key" UNIQUE (token);


--
-- TOC entry 3289 (class 2606 OID 31175)
-- Name: Roles Roles_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_name_key" UNIQUE (name);


--
-- TOC entry 3291 (class 2606 OID 31173)
-- Name: Roles Roles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_pkey" PRIMARY KEY (id);


--
-- TOC entry 3285 (class 2606 OID 27740)
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- TOC entry 3293 (class 2606 OID 31186)
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- TOC entry 3295 (class 2606 OID 31190)
-- Name: Users Users_googleId_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_googleId_key" UNIQUE ("googleId");


--
-- TOC entry 3297 (class 2606 OID 31188)
-- Name: Users Users_phone_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_phone_key" UNIQUE (phone);


--
-- TOC entry 3299 (class 2606 OID 31184)
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- TOC entry 3301 (class 2606 OID 31206)
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- TOC entry 3305 (class 2606 OID 31233)
-- Name: exercises exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_pkey PRIMARY KEY (exercise_id);


--
-- TOC entry 3303 (class 2606 OID 31217)
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- TOC entry 3307 (class 2606 OID 31247)
-- Name: materials materials_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_pkey PRIMARY KEY (material_id);


--
-- TOC entry 3309 (class 2606 OID 31263)
-- Name: progresses progresses_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.progresses
    ADD CONSTRAINT progresses_pkey PRIMARY KEY (progress_id);


--
-- TOC entry 3315 (class 2606 OID 31300)
-- Name: stream_students stream_students_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stream_students
    ADD CONSTRAINT stream_students_pkey PRIMARY KEY (id);


--
-- TOC entry 3311 (class 2606 OID 31282)
-- Name: streams streams_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_name_key UNIQUE (name);


--
-- TOC entry 3313 (class 2606 OID 31280)
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (id);


--
-- TOC entry 3332 (class 2606 OID 31318)
-- Name: Files Files_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_material_id_fkey" FOREIGN KEY (material_id) REFERENCES public.materials(material_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3333 (class 2606 OID 31332)
-- Name: PasswordResetTokens PasswordResetTokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PasswordResetTokens"
    ADD CONSTRAINT "PasswordResetTokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3322 (class 2606 OID 31191)
-- Name: Users Users_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Roles"(id);


--
-- TOC entry 3324 (class 2606 OID 31234)
-- Name: exercises exercises_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id);


--
-- TOC entry 3323 (class 2606 OID 31218)
-- Name: lessons lessons_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- TOC entry 3325 (class 2606 OID 31248)
-- Name: materials materials_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3326 (class 2606 OID 31269)
-- Name: progresses progresses_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.progresses
    ADD CONSTRAINT progresses_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id);


--
-- TOC entry 3327 (class 2606 OID 31264)
-- Name: progresses progresses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.progresses
    ADD CONSTRAINT progresses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."Users"(id);


--
-- TOC entry 3330 (class 2606 OID 31301)
-- Name: stream_students stream_students_streamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stream_students
    ADD CONSTRAINT "stream_students_streamId_fkey" FOREIGN KEY ("streamId") REFERENCES public.streams(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3331 (class 2606 OID 31306)
-- Name: stream_students stream_students_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stream_students
    ADD CONSTRAINT "stream_students_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3328 (class 2606 OID 31283)
-- Name: streams streams_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public.courses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3329 (class 2606 OID 31288)
-- Name: streams streams_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.streams
    ADD CONSTRAINT "streams_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


-- Completed on 2025-04-16 06:13:42 UTC

--
-- PostgreSQL database dump complete
--

